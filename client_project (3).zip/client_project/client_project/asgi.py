import os
from django.core.asgi_application import get_asgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'client_project.settings')
application = get_asgi_application()
